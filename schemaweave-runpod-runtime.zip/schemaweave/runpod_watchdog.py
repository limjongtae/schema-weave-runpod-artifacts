import http.client
import json
import os
import re
import signal
import ssl
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Protocol

RUNPOD_API_HOST = "rest.runpod.io"
MAX_CONTROL_RESPONSE_BYTES = 64 * 1024
REMOTE_STOP_AFTER = timedelta(minutes=110)
SAFETY_CANARY_STOP_AFTER = timedelta(minutes=5)
MAX_OBSERVED_SESSION_AGE = timedelta(minutes=120)
MAX_CLOCK_SKEW = timedelta(minutes=2)
STOP_RETRY_SECONDS = 5.0
ATTESTATION_RECHECK_SECONDS = 30.0
CA_BUNDLE_PATH = Path("/etc/ssl/certs/ca-certificates.crt")
MAX_CA_BUNDLE_BYTES = 1024 * 1024


def _tls_context() -> ssl.SSLContext:
    if (
        CA_BUNDLE_PATH.is_symlink()
        or not CA_BUNDLE_PATH.is_file()
        or not 1 <= CA_BUNDLE_PATH.stat().st_size <= MAX_CA_BUNDLE_BYTES
    ):
        raise RuntimeError("RunPod watchdog CA bundle is unavailable")
    return ssl.create_default_context(cafile=str(CA_BUNDLE_PATH))


class WatchdogTransport(Protocol):
    def get(self, pod_id: str, token: bytes) -> "ControlResponse": ...

    def stop(self, pod_id: str, token: bytes) -> "ControlResponse": ...


@dataclass(frozen=True)
class ControlResponse:
    body: bytes
    server_time: datetime


class RunPodRestTransport:
    def _request(self, method: str, path: str, token: bytes) -> ControlResponse:
        connection = http.client.HTTPSConnection(
            RUNPOD_API_HOST,
            timeout=10.0,
            context=_tls_context(),
        )
        try:
            connection.request(method, path, headers={"Authorization": b"Bearer " + token})
            response = connection.getresponse()
            body = response.read(MAX_CONTROL_RESPONSE_BYTES + 1)
            if response.status != 200 or len(body) > MAX_CONTROL_RESPONSE_BYTES:
                raise RuntimeError("RunPod watchdog control request failed")
            raw_date = response.getheader("Date")
            if raw_date is None:
                raise RuntimeError("RunPod watchdog server time is missing")
            try:
                server_time = parsedate_to_datetime(raw_date).astimezone(UTC)
            except (TypeError, ValueError):
                raise RuntimeError("RunPod watchdog server time is invalid") from None
            return ControlResponse(body=body, server_time=server_time)
        finally:
            connection.close()

    def get(self, pod_id: str, token: bytes) -> ControlResponse:
        return self._request("GET", f"/v1/pods/{pod_id}", token)

    def stop(self, pod_id: str, token: bytes) -> ControlResponse:
        return self._request("POST", f"/v1/pods/{pod_id}/stop", token)


@dataclass(frozen=True)
class PodState:
    pod_id: str
    desired_status: str
    last_started_at: datetime | None


@dataclass(frozen=True)
class ObservedPodState:
    state: PodState
    server_time: datetime


def _parse_timestamp(value: object) -> datetime:
    if not isinstance(value, str):
        raise ValueError("RunPod watchdog timestamp is missing")
    normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        raise ValueError("RunPod watchdog timestamp is not timezone-aware")
    return parsed.astimezone(UTC)


def parse_state(payload: bytes, expected_pod_id: str) -> PodState:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("RunPod watchdog response is invalid") from None
    if not isinstance(value, dict) or value.get("id") != expected_pod_id:
        raise ValueError("RunPod watchdog ownership does not match")
    desired_status = value.get("desiredStatus")
    if desired_status not in {"RUNNING", "EXITED"}:
        raise ValueError("RunPod watchdog status is unsafe")
    raw_last_started_at = value.get("lastStartedAt")
    last_started_at: datetime | None
    if desired_status == "RUNNING":
        last_started_at = _parse_timestamp(raw_last_started_at)
    else:
        last_started_at = (
            None if raw_last_started_at is None else _parse_timestamp(raw_last_started_at)
        )
    return PodState(
        pod_id=expected_pod_id,
        desired_status=desired_status,
        last_started_at=last_started_at,
    )


def read_credentials_from_fd() -> tuple[str, bytes]:
    raw_fd = os.environ.pop("SCHEMAWEAVE_WATCHDOG_CREDENTIAL_FD", "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError("watchdog credential file descriptor is missing")
    with os.fdopen(int(raw_fd), "rb", closefd=True) as credential_file:
        value = credential_file.read(8193)
    try:
        pod_id_raw, token = value.split(b"\n", maxsplit=1)
        pod_id = pod_id_raw.decode("ascii")
    except (UnicodeDecodeError, ValueError):
        raise RuntimeError("watchdog credential payload is invalid") from None
    if (
        not re.fullmatch(r"[A-Za-z0-9_-]{3,64}", pod_id)
        or not 16 <= len(token) <= 4096
        or any(character in b" \t\r\n" for character in token)
    ):
        raise RuntimeError("watchdog credential payload is invalid")
    return pod_id, token


def signal_ready() -> None:
    raw_fd = os.environ.pop("SCHEMAWEAVE_WATCHDOG_READY_FD", "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError("watchdog readiness file descriptor is missing")
    with os.fdopen(int(raw_fd), "wb", closefd=True) as ready_file:
        ready_file.write(b"1")
        ready_file.flush()


class RemoteWatchdog:
    def __init__(
        self,
        *,
        pod_id: str,
        token: bytes,
        transport: WatchdogTransport | None = None,
        stop_after: timedelta = REMOTE_STOP_AFTER,
        monotonic: Callable[[], float] | None = None,
        sleep: Callable[[float], None] | None = None,
        ready: Callable[[], None] | None = None,
        stop_requested: Callable[[], bool] | None = None,
    ) -> None:
        self._pod_id = pod_id
        self._token = token
        self._transport = transport or RunPodRestTransport()
        if not timedelta(seconds=1) <= stop_after <= REMOTE_STOP_AFTER:
            raise ValueError("remote watchdog deadline is unsafe")
        self._stop_after = stop_after
        self._monotonic = monotonic or time.monotonic
        self._sleep = sleep or time.sleep
        self._ready = ready or signal_ready
        self._stop_requested = stop_requested or (lambda: False)

    def run(self) -> None:
        try:
            initial = self._get_verified_state()
            if initial.state.desired_status != "RUNNING":
                raise ValueError("RunPod watchdog did not observe a running Pod")
            initial_started_at = initial.state.last_started_at
            if initial_started_at is None:
                raise ValueError("RunPod watchdog start timestamp is missing")
            age = initial.server_time - initial_started_at
            if age < -MAX_CLOCK_SKEW or age > MAX_OBSERVED_SESSION_AGE:
                raise ValueError("RunPod watchdog observed an unsafe session age")
        except (OSError, RuntimeError, ValueError):
            self.stop_until_confirmed()
            return

        deadline = initial_started_at + self._stop_after
        remaining = (deadline - initial.server_time).total_seconds()
        if remaining <= 0:
            self.stop_until_confirmed()
            return
        if self._stop_requested():
            self.stop_until_confirmed()
            return
        try:
            self._ready()
        except (OSError, RuntimeError, ValueError):
            self.stop_until_confirmed()
            return
        monotonic_deadline = self._monotonic() + remaining
        while True:
            if self._stop_requested():
                break
            remaining = monotonic_deadline - self._monotonic()
            if remaining <= 0:
                break
            self._sleep(min(ATTESTATION_RECHECK_SECONDS, remaining))
            try:
                current = self._get_verified_state()
            except (OSError, RuntimeError, ValueError):
                break
            if (
                current.state.desired_status != "RUNNING"
                or current.state.last_started_at != initial_started_at
                or current.server_time < initial.server_time - MAX_CLOCK_SKEW
                or current.server_time >= deadline
            ):
                break
        self.stop_until_confirmed()

    def _get_verified_state(self) -> ObservedPodState:
        response = self._transport.get(self._pod_id, self._token)
        return ObservedPodState(
            state=parse_state(response.body, self._pod_id),
            server_time=response.server_time,
        )

    def stop_until_confirmed(self) -> None:
        while True:
            try:
                state = self._get_verified_state()
                if state.state.desired_status == "EXITED":
                    return
            except (OSError, RuntimeError, ValueError):
                pass
            try:
                self._transport.stop(self._pod_id, self._token)
            except (OSError, RuntimeError, ValueError):
                self._sleep(STOP_RETRY_SECONDS)
                continue
            try:
                confirmed = self._get_verified_state()
                if confirmed.state.desired_status == "EXITED":
                    return
            except (OSError, RuntimeError, ValueError):
                pass
            self._sleep(STOP_RETRY_SECONDS)


def main() -> None:
    pod_id, token = read_credentials_from_fd()
    mode = os.environ.pop("SCHEMAWEAVE_WATCHDOG_MODE", "production")
    emergency_stop = False
    if mode == "production":
        stop_after = REMOTE_STOP_AFTER
    elif mode == "safety-canary":
        stop_after = SAFETY_CANARY_STOP_AFTER
    elif mode == "emergency-stop":
        stop_after = REMOTE_STOP_AFTER
        emergency_stop = True
    else:
        raise RuntimeError("watchdog mode is invalid")
    stop_requested = threading.Event()

    def request_stop(_: int, __: object) -> None:
        stop_requested.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGUSR1, request_stop)
    watchdog = RemoteWatchdog(
        pod_id=pod_id,
        token=token,
        stop_after=stop_after,
        stop_requested=stop_requested.is_set,
    )
    if emergency_stop:
        watchdog.stop_until_confirmed()
    else:
        watchdog.run()


if __name__ == "__main__":
    main()
