import hashlib
import http.client
import json
import os
import re
import signal
import ssl
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Protocol

RUNPOD_API_HOST = "rest.runpod.io"
MAX_CONTROL_RESPONSE_BYTES = 64 * 1024
REMOTE_STOP_AFTER = timedelta(minutes=110)
SAFETY_CANARY_STOP_AFTER = timedelta(minutes=5)
SAFETY_CANARY_MINIMUM_OBSERVATION = timedelta(minutes=5)
MAX_OBSERVED_SESSION_AGE = timedelta(minutes=120)
MAX_CLOCK_SKEW = timedelta(minutes=2)
STOP_RETRY_SECONDS = 5.0
ATTESTATION_RECHECK_SECONDS = 20.0
MAX_ATTESTATION_OBSERVATION_GAP = timedelta(seconds=30)
CA_BUNDLE_PATH = Path("/etc/ssl/certs/ca-certificates.crt")
BOOT_ID_PATH = Path("/proc/sys/kernel/random/boot_id")
MAX_CA_BUNDLE_BYTES = 1024 * 1024


def _tls_context() -> ssl.SSLContext:
    if (
        CA_BUNDLE_PATH.is_symlink()
        or not CA_BUNDLE_PATH.is_file()
        or not 1 <= CA_BUNDLE_PATH.stat().st_size <= MAX_CA_BUNDLE_BYTES
    ):
        raise RuntimeError("RunPod watchdog CA bundle is unavailable")
    return ssl.create_default_context(cafile=str(CA_BUNDLE_PATH))


class WatchdogTransport(Protocol):
    def get(self, pod_id: str, token: bytes) -> "ControlResponse": ...

    def stop(self, pod_id: str, token: bytes) -> "ControlResponse": ...


@dataclass(frozen=True)
class ControlResponse:
    body: bytes
    server_time: datetime


class RunPodRestTransport:
    def _request(self, method: str, path: str, token: bytes) -> ControlResponse:
        connection = http.client.HTTPSConnection(
            RUNPOD_API_HOST,
            timeout=10.0,
            context=_tls_context(),
        )
        try:
            connection.request(method, path, headers={"Authorization": b"Bearer " + token})
            response = connection.getresponse()
            body = response.read(MAX_CONTROL_RESPONSE_BYTES + 1)
            if response.status != 200 or len(body) > MAX_CONTROL_RESPONSE_BYTES:
                raise RuntimeError("RunPod watchdog control request failed")
            raw_date = response.getheader("Date")
            if raw_date is None:
                raise RuntimeError("RunPod watchdog server time is missing")
            try:
                server_time = parsedate_to_datetime(raw_date).astimezone(UTC)
            except (TypeError, ValueError):
                raise RuntimeError("RunPod watchdog server time is invalid") from None
            return ControlResponse(body=body, server_time=server_time)
        finally:
            connection.close()

    def get(self, pod_id: str, token: bytes) -> ControlResponse:
        return self._request("GET", f"/v1/pods/{pod_id}", token)

    def stop(self, pod_id: str, token: bytes) -> ControlResponse:
        return self._request("POST", f"/v1/pods/{pod_id}/stop", token)


@dataclass(frozen=True)
class PodState:
    pod_id: str
    desired_status: str
    last_started_at: datetime | None


@dataclass(frozen=True)
class ObservedPodState:
    state: PodState
    server_time: datetime


def _parse_timestamp(value: object) -> datetime:
    if not isinstance(value, str):
        raise ValueError("RunPod watchdog timestamp is missing")
    if not re.fullmatch(
        r"\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?"
        r"(?:Z|[+-](?:(?:0\d|1[0-3]):[0-5]\d|14:00))| "
        r"\d{2}:\d{2}:\d{2}\.\d{3} \+0000 UTC)",
        value,
        flags=re.ASCII,
    ):
        raise ValueError("RunPod watchdog timestamp format is unsupported")
    if value[10] == " ":
        normalized = value[:23] + "+00:00"
    else:
        normalized = value[:-1] + "+00:00" if value.endswith("Z") else value
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        raise ValueError("RunPod watchdog timestamp is invalid") from None
    return parsed.astimezone(UTC)


def parse_state(payload: bytes, expected_pod_id: str) -> PodState:
    try:
        value = json.loads(payload)
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("RunPod watchdog response is invalid") from None
    if not isinstance(value, dict) or value.get("id") != expected_pod_id:
        raise ValueError("RunPod watchdog ownership does not match")
    desired_status = value.get("desiredStatus")
    if desired_status not in {"RUNNING", "EXITED"}:
        raise ValueError("RunPod watchdog status is unsafe")
    raw_last_started_at = value.get("lastStartedAt")
    last_started_at: datetime | None
    if desired_status == "RUNNING":
        last_started_at = _parse_timestamp(raw_last_started_at)
    else:
        last_started_at = (
            None if raw_last_started_at is None else _parse_timestamp(raw_last_started_at)
        )
    return PodState(
        pod_id=expected_pod_id,
        desired_status=desired_status,
        last_started_at=last_started_at,
    )


def read_credentials_from_fd() -> tuple[str, str, bytes]:
    raw_fd = os.environ.pop("SCHEMAWEAVE_WATCHDOG_CREDENTIAL_FD", "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError("watchdog credential file descriptor is missing")
    with os.fdopen(int(raw_fd), "rb", closefd=True) as credential_file:
        value = credential_file.read(8193)
    try:
        pod_id_raw, nonce_raw, token = value.split(b"\n", maxsplit=2)
        pod_id = pod_id_raw.decode("ascii")
        nonce_digest = nonce_raw.decode("ascii")
    except (UnicodeDecodeError, ValueError):
        raise RuntimeError("watchdog credential payload is invalid") from None
    if (
        not re.fullmatch(r"[A-Za-z0-9_-]{3,64}", pod_id)
        or not re.fullmatch(r"[0-9a-f]{64}", nonce_digest)
        or not 16 <= len(token) <= 4096
        or any(character in b" \t\r\n" for character in token)
    ):
        raise RuntimeError("watchdog credential payload is invalid")
    return pod_id, nonce_digest, token


def emit_self_stop_attestation(
    state: PodState,
    observed_seconds: float,
    observation_count: int,
    transcript_sha256: str,
    pod_id: str,
    create_nonce_sha256: str,
) -> None:
    boot_id = BOOT_ID_PATH.read_text(encoding="ascii").strip()
    if not re.fullmatch(r"[0-9a-f-]{36}", boot_id):
        raise RuntimeError("watchdog boot identity is invalid")
    pod_id_sha256 = hashlib.sha256(pod_id.encode("ascii")).hexdigest()
    boot_id_sha256 = hashlib.sha256(boot_id.encode("ascii")).hexdigest()
    started_at = state.last_started_at.isoformat() if state.last_started_at else ""
    session_id_sha256 = hashlib.sha256(
        f"{create_nonce_sha256}:{pod_id_sha256}:{boot_id_sha256}:{started_at}".encode("ascii")
    ).hexdigest()
    payload = {
        "boot_id_sha256": boot_id_sha256,
        "create_nonce_sha256": create_nonce_sha256,
        "kind": "SCHEMAWEAVE_WATCHDOG_SELF_STOP_REQUESTED",
        "observation_count": observation_count,
        "observed_seconds": int(observed_seconds),
        "pod_id_sha256": pod_id_sha256,
        "schema_version": 1,
        "session_id_sha256": session_id_sha256,
        "started_at": started_at,
        "transcript_sha256": transcript_sha256,
    }
    print(json.dumps(payload, sort_keys=True, separators=(",", ":")), flush=True)


def signal_ready() -> None:
    raw_fd = os.environ.pop("SCHEMAWEAVE_WATCHDOG_READY_FD", "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError("watchdog readiness file descriptor is missing")
    with os.fdopen(int(raw_fd), "wb", closefd=True) as ready_file:
        ready_file.write(b"1")
        ready_file.flush()


class RemoteWatchdog:
    def __init__(
        self,
        *,
        pod_id: str,
        token: bytes,
        transport: WatchdogTransport | None = None,
        stop_after: timedelta = REMOTE_STOP_AFTER,
        monotonic: Callable[[], float] | None = None,
        sleep: Callable[[float], None] | None = None,
        ready: Callable[[], None] | None = None,
        stop_requested: Callable[[], bool] | None = None,
        minimum_observation: timedelta = timedelta(0),
        attest: Callable[[PodState, float, int, str], None] | None = None,
    ) -> None:
        self._pod_id = pod_id
        self._token = token
        self._transport = transport or RunPodRestTransport()
        if not timedelta(seconds=1) <= stop_after <= REMOTE_STOP_AFTER:
            raise ValueError("remote watchdog deadline is unsafe")
        self._stop_after = stop_after
        if not timedelta(0) <= minimum_observation <= SAFETY_CANARY_MINIMUM_OBSERVATION:
            raise ValueError("remote watchdog observation window is unsafe")
        self._minimum_observation = minimum_observation
        self._monotonic = monotonic or time.monotonic
        self._sleep = sleep or time.sleep
        self._ready = ready or signal_ready
        self._stop_requested = stop_requested or (lambda: False)
        self._attest = attest

    def run(self) -> None:
        try:
            initial = self._get_verified_state()
            if initial.state.desired_status != "RUNNING":
                raise ValueError("RunPod watchdog did not observe a running Pod")
            initial_started_at = initial.state.last_started_at
            if initial_started_at is None:
                raise ValueError("RunPod watchdog start timestamp is missing")
            age = initial.server_time - initial_started_at
            if age < -MAX_CLOCK_SKEW or age > MAX_OBSERVED_SESSION_AGE:
                raise ValueError("RunPod watchdog observed an unsafe session age")
        except (OSError, RuntimeError, ValueError):
            self.stop_until_confirmed()
            return

        deadline = max(
            initial_started_at + self._stop_after,
            initial.server_time + self._minimum_observation,
        )
        if deadline - initial_started_at > MAX_OBSERVED_SESSION_AGE:
            self.stop_until_confirmed()
            return
        remaining = (deadline - initial.server_time).total_seconds()
        if remaining <= 0:
            self.stop_until_confirmed()
            return
        if self._stop_requested():
            self.stop_until_confirmed()
            return
        try:
            self._ready()
        except (OSError, RuntimeError, ValueError):
            self.stop_until_confirmed()
            return
        observation_started = self._monotonic()
        monotonic_deadline = observation_started + remaining
        last_observation = observation_started
        next_observation = observation_started + ATTESTATION_RECHECK_SECONDS
        transcript = bytes(32)
        observation_count = 0

        def record(observation: ObservedPodState, elapsed: float, gap: float) -> None:
            nonlocal transcript, observation_count
            encoded = json.dumps(
                {
                    "desired_status": observation.state.desired_status,
                    "last_started_at": (
                        observation.state.last_started_at.isoformat()
                        if observation.state.last_started_at
                        else None
                    ),
                    "monotonic_elapsed_ms": int(elapsed * 1000),
                    "monotonic_gap_ms": int(gap * 1000),
                    "sequence": observation_count,
                    "server_time": observation.server_time.isoformat(),
                },
                sort_keys=True,
                separators=(",", ":"),
            ).encode("ascii")
            transcript = hashlib.sha256(transcript + encoded).digest()
            observation_count += 1

        record(initial, 0.0, 0.0)
        deadline_reached = False
        while True:
            if self._stop_requested():
                break
            target = min(next_observation, monotonic_deadline)
            delay = target - self._monotonic()
            if delay > 0:
                self._sleep(delay)
            try:
                current = self._get_verified_state()
            except (OSError, RuntimeError, ValueError):
                break
            observed_monotonic = self._monotonic()
            gap = observed_monotonic - last_observation
            if gap > MAX_ATTESTATION_OBSERVATION_GAP.total_seconds():
                break
            elapsed = observed_monotonic - observation_started
            record(current, elapsed, gap)
            if (
                current.state.desired_status != "RUNNING"
                or current.state.last_started_at != initial_started_at
                or current.server_time < initial.server_time - MAX_CLOCK_SKEW
            ):
                break
            if observed_monotonic >= monotonic_deadline or current.server_time >= deadline:
                deadline_reached = elapsed >= self._minimum_observation.total_seconds()
                break
            last_observation = observed_monotonic
            next_observation += ATTESTATION_RECHECK_SECONDS
        if deadline_reached and self._attest is not None:
            try:
                self._attest(
                    initial.state,
                    self._monotonic() - observation_started,
                    observation_count,
                    transcript.hex(),
                )
            except (OSError, RuntimeError, ValueError):
                self.stop_until_confirmed()
                return
        self.stop_until_confirmed()

    def _get_verified_state(self) -> ObservedPodState:
        response = self._transport.get(self._pod_id, self._token)
        return ObservedPodState(
            state=parse_state(response.body, self._pod_id),
            server_time=response.server_time,
        )

    def stop_until_confirmed(self) -> None:
        while True:
            try:
                state = self._get_verified_state()
                if state.state.desired_status == "EXITED":
                    return
            except (OSError, RuntimeError, ValueError):
                pass
            try:
                self._transport.stop(self._pod_id, self._token)
            except (OSError, RuntimeError, ValueError):
                self._sleep(STOP_RETRY_SECONDS)
                continue
            try:
                confirmed = self._get_verified_state()
                if confirmed.state.desired_status == "EXITED":
                    return
            except (OSError, RuntimeError, ValueError):
                pass
            self._sleep(STOP_RETRY_SECONDS)


def main() -> None:
    pod_id, create_nonce_sha256, token = read_credentials_from_fd()
    mode = os.environ.pop("SCHEMAWEAVE_WATCHDOG_MODE", "production")
    emergency_stop = False
    if mode == "production":
        stop_after = REMOTE_STOP_AFTER
    elif mode == "safety-canary":
        stop_after = SAFETY_CANARY_STOP_AFTER
    elif mode == "emergency-stop":
        stop_after = REMOTE_STOP_AFTER
        emergency_stop = True
    else:
        raise RuntimeError("watchdog mode is invalid")
    stop_requested = threading.Event()

    def request_stop(_: int, __: object) -> None:
        stop_requested.set()

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    signal.signal(signal.SIGUSR1, request_stop)

    def self_stop_attestation(state: PodState, seconds: float, count: int, transcript: str) -> None:
        emit_self_stop_attestation(
            state,
            seconds,
            count,
            transcript,
            pod_id,
            create_nonce_sha256,
        )

    attestation = self_stop_attestation if mode == "safety-canary" else None
    watchdog = RemoteWatchdog(
        pod_id=pod_id,
        token=token,
        stop_after=stop_after,
        stop_requested=stop_requested.is_set,
        minimum_observation=(
            SAFETY_CANARY_MINIMUM_OBSERVATION if mode == "safety-canary" else timedelta(0)
        ),
        attest=attestation,
    )
    if emergency_stop:
        watchdog.stop_until_confirmed()
    else:
        watchdog.run()


if __name__ == "__main__":
    main()
