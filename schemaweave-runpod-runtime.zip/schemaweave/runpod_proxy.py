import hashlib
import hmac
import json
import os
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

MAX_PROXY_REQUEST_BYTES = 64 * 1024
MAX_PROXY_RESPONSE_BYTES = 256 * 1024
MAX_PROXY_HEALTH_RESPONSE_BYTES = 1024
UPSTREAM_URL = "http://127.0.0.1:8001/v1/chat/completions"
UPSTREAM_HEALTH_URL = "http://127.0.0.1:8001/health"

Scope = dict[str, Any]
Message = dict[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]


class SecureRunPodProxy:
    """Minimal raw-ASGI boundary for the single permitted vLLM operation."""

    def __init__(
        self,
        expected_token: bytes,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not 16 <= len(expected_token) <= 4096 or any(
            character in b" \t\r\n" for character in expected_token
        ):
            raise ValueError("inference token is invalid")
        self._expected_digest = hashlib.sha256(expected_token).digest()
        self._transport = transport

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            raise RuntimeError("only HTTP ASGI scopes are supported")
        health_operation = self._is_health_operation(scope)
        if not self._is_exact_operation(scope) and not health_operation:
            await self._respond(send, 404)
            return
        if not self._is_authorized(scope):
            await self._respond(send, 401)
            return
        if health_operation:
            await self._forward_health(send)
            return
        if not self._is_json(scope):
            await self._respond(send, 415)
            return

        body = await self._read_body(receive)
        if body is None:
            await self._respond(send, 413)
            return
        if not self._is_openai_request(body):
            await self._respond(send, 400)
            return
        await self._forward(body, send)

    @staticmethod
    def _headers(scope: Scope, name: bytes) -> list[bytes]:
        return [value for key, value in scope.get("headers", []) if key.lower() == name]

    @staticmethod
    def _is_exact_operation(scope: Scope) -> bool:
        return (
            scope.get("method") == "POST"
            and scope.get("raw_path") == b"/v1/chat/completions"
            and scope.get("query_string", b"") == b""
        )

    @staticmethod
    def _is_health_operation(scope: Scope) -> bool:
        return (
            scope.get("method") == "GET"
            and scope.get("raw_path") == b"/health"
            and scope.get("query_string", b"") == b""
        )

    def _is_authorized(self, scope: Scope) -> bool:
        values = self._headers(scope, b"authorization")
        presented = b""
        if len(values) == 1 and values[0].startswith(b"Bearer "):
            presented = values[0][len(b"Bearer ") :]
        presented_digest = hashlib.sha256(presented).digest()
        return len(values) == 1 and hmac.compare_digest(presented_digest, self._expected_digest)

    def _is_json(self, scope: Scope) -> bool:
        values = self._headers(scope, b"content-type")
        return len(values) == 1 and values[0].lower() == b"application/json"

    @staticmethod
    async def _read_body(receive: Receive) -> bytes | None:
        body = bytearray()
        while True:
            message = await receive()
            if message.get("type") == "http.disconnect":
                return None
            if message.get("type") != "http.request":
                return None
            chunk = message.get("body", b"")
            if not isinstance(chunk, bytes):
                return None
            body.extend(chunk)
            if len(body) > MAX_PROXY_REQUEST_BYTES:
                return None
            if not message.get("more_body", False):
                return bytes(body)

    async def _forward(self, body: bytes, send: Send) -> None:
        timeout = httpx.Timeout(connect=5.0, read=80.0, write=5.0, pool=5.0)
        try:
            async with (
                httpx.AsyncClient(
                    follow_redirects=False,
                    timeout=timeout,
                    transport=self._transport,
                    trust_env=False,
                ) as client,
                client.stream(
                    "POST",
                    UPSTREAM_URL,
                    headers={"content-type": "application/json"},
                    content=body,
                ) as response,
            ):
                if response.status_code != 200:
                    await self._respond(send, 502)
                    return
                content_type = response.headers.get("content-type", "")
                if content_type.split(";", maxsplit=1)[0].strip().lower() != "application/json":
                    await self._respond(send, 502)
                    return
                response_body = bytearray()
                async for chunk in response.aiter_bytes():
                    response_body.extend(chunk)
                    if len(response_body) > MAX_PROXY_RESPONSE_BYTES:
                        await self._respond(send, 502)
                        return
        except (httpx.RequestError, httpx.TimeoutException):
            await self._respond(send, 502)
            return

        bounded_response = bytes(response_body)
        if not self._is_openai_response(bounded_response):
            await self._respond(send, 502)
            return
        await self._respond(send, 200, bounded_response, b"application/json")

    async def _forward_health(self, send: Send) -> None:
        try:
            async with (
                httpx.AsyncClient(
                    follow_redirects=False,
                    timeout=httpx.Timeout(5.0),
                    transport=self._transport,
                    trust_env=False,
                ) as client,
                client.stream("GET", UPSTREAM_HEALTH_URL) as response,
            ):
                content_length = response.headers.get("content-length")
                if content_length is not None and (
                    not content_length.isascii()
                    or not content_length.isdecimal()
                    or int(content_length) > MAX_PROXY_HEALTH_RESPONSE_BYTES
                ):
                    await self._respond(send, 503)
                    return
                status_code = response.status_code
        except (httpx.RequestError, httpx.TimeoutException):
            await self._respond(send, 503)
            return
        await self._respond(send, 200 if status_code == 200 else 503)

    @staticmethod
    def _json_object(payload: bytes) -> dict[str, Any] | None:
        def reject_constant(_: str) -> None:
            raise ValueError

        try:
            value = json.loads(payload, parse_constant=reject_constant)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            return None
        return value if isinstance(value, dict) else None

    @classmethod
    def _is_openai_request(cls, payload: bytes) -> bool:
        value = cls._json_object(payload)
        return (
            value is not None
            and isinstance(value.get("model"), str)
            and bool(value["model"])
            and isinstance(value.get("messages"), list)
            and bool(value["messages"])
            and value.get("stream") is False
        )

    @classmethod
    def _is_openai_response(cls, payload: bytes) -> bool:
        value = cls._json_object(payload)
        return (
            value is not None
            and isinstance(value.get("model"), str)
            and bool(value["model"])
            and isinstance(value.get("choices"), list)
            and bool(value["choices"])
        )

    @staticmethod
    async def _respond(
        send: Send,
        status: int,
        body: bytes = b"",
        content_type: bytes = b"text/plain",
    ) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": status,
                "headers": [
                    (b"content-type", content_type),
                    (b"content-length", str(len(body)).encode("ascii")),
                    (b"cache-control", b"no-store"),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})


def create_app_from_fd() -> SecureRunPodProxy:
    raw_fd = os.environ.pop("SCHEMAWEAVE_PROXY_TOKEN_FD", "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError("proxy token file descriptor is missing")
    with os.fdopen(int(raw_fd), "rb", closefd=True) as token_file:
        token = token_file.read(4097)
    if len(token) > 4096:
        raise RuntimeError("proxy token is too large")
    return SecureRunPodProxy(token)
