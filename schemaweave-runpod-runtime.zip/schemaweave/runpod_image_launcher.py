import ctypes
import os
import signal
import stat
import subprocess
import sys
import time
from contextlib import suppress
from dataclasses import dataclass
from types import FrameType

MODEL_ID = "Qwen/Qwen2.5-Coder-14B-Instruct-AWQ"
MODEL_REVISION = "eb3172f06a6d6b3a15f08947b0668d782e4d2d2c"
INFERENCE_TOKEN_FD_ENV = "SCHEMAWEAVE_INFERENCE_TOKEN_FD"
BOOTSTRAP_AUTH_FD_ENV = "SCHEMAWEAVE_BOOTSTRAP_AUTH_FD"
PR_SET_DUMPABLE = 4
PR_SET_NO_NEW_PRIVS = 38
CHILD_STOP_SECONDS = 10.0
RUNTIME_PATH = (
    "/usr/local/nvidia/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
)
SCHEMAWEAVE_PYTHONPATH = "/opt/schemaweave"


@dataclass(frozen=True)
class RuntimeUser:
    uid: int
    gid: int
    home: str


RUNTIME_USERS = {
    "vllm": RuntimeUser(10001, 10001, "/home/schema-vllm"),
    "proxy": RuntimeUser(10002, 10002, "/home/schema-proxy"),
}


def _set_process_hardening() -> None:
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_DUMPABLE, 0, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "failed to disable process dumpability")


def _prepare_runtime_homes() -> None:
    for user in RUNTIME_USERS.values():
        path = os.path.abspath(user.home)
        try:
            status = os.lstat(path)
        except FileNotFoundError:
            os.mkdir(path, mode=0o700)
            os.chown(path, user.uid, user.gid)
            status = os.lstat(path)
        if (
            not stat.S_ISDIR(status.st_mode)
            or stat.S_IMODE(status.st_mode) != 0o700
            or status.st_uid != user.uid
            or status.st_gid != user.gid
        ):
            raise RuntimeError("RunPod runtime home is unsafe")


def _demote(user: RuntimeUser) -> None:
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "failed to set no-new-privileges")
    os.setgroups([])
    os.setgid(user.gid)
    os.setuid(user.uid)
    if libc.prctl(PR_SET_DUMPABLE, 0, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "failed to disable child dumpability")
    os.umask(0o077)


def _child_environment(role: str) -> dict[str, str]:
    user = RUNTIME_USERS[role]
    keep = {
        "CUDA_HOME",
        "CUDA_VISIBLE_DEVICES",
        "LANG",
        "LC_ALL",
        "LD_LIBRARY_PATH",
        "NVIDIA_DRIVER_CAPABILITIES",
        "NVIDIA_REQUIRE_CUDA",
        "NVIDIA_VISIBLE_DEVICES",
    }
    environment = {key: value for key, value in os.environ.items() if key in keep}
    environment.update(
        {
            "HOME": user.home,
            "HF_HOME": f"{user.home}/.cache/huggingface",
            "HF_HUB_DISABLE_TELEMETRY": "1",
            "DO_NOT_TRACK": "1",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1",
            "PATH": RUNTIME_PATH,
            "PYTHONPATH": SCHEMAWEAVE_PYTHONPATH,
        }
    )
    if role == "vllm":
        environment["VLLM_LOGGING_LEVEL"] = "WARNING"
        environment["VLLM_NO_USAGE_STATS"] = "1"
    return environment


def vllm_command() -> list[str]:
    return [
        "/usr/local/bin/vllm",
        "serve",
        MODEL_ID,
        "--host",
        "127.0.0.1",
        "--port",
        "8001",
        "--revision",
        MODEL_REVISION,
        "--served-model-name",
        MODEL_ID,
        "--max-model-len",
        "8192",
        "--max-num-seqs",
        "1",
        "--gpu-memory-utilization",
        "0.90",
        "--generation-config",
        "vllm",
        "--no-enable-log-requests",
        "--no-enable-log-outputs",
        "--disable-log-stats",
        "--disable-fastapi-docs",
    ]


def proxy_command() -> list[str]:
    return [
        sys.executable,
        "-m",
        "uvicorn",
        "schemaweave.runpod_proxy:create_app_from_fd",
        "--factory",
        "--host",
        "0.0.0.0",
        "--port",
        "8000",
        "--workers",
        "1",
        "--lifespan",
        "off",
        "--no-access-log",
        "--log-level",
        "warning",
    ]


def _pipe_payload(payload: bytes) -> int:
    read_fd, write_fd = os.pipe()
    try:
        os.write(write_fd, payload)
    finally:
        os.close(write_fd)
    return read_fd


def _spawn(
    command: list[str],
    role: str,
    *,
    pass_fds: tuple[int, ...] = (),
    extra_env: dict[str, str] | None = None,
) -> subprocess.Popen[bytes]:
    environment = _child_environment(role)
    environment.update(extra_env or {})
    user = RUNTIME_USERS[role]
    return subprocess.Popen(
        command,
        env=environment,
        pass_fds=pass_fds,
        start_new_session=False,
        preexec_fn=lambda: _demote(user),
    )


def _read_required_fd(name: str, maximum: int) -> bytes:
    raw_fd = os.environ.pop(name, "")
    if not raw_fd.isascii() or not raw_fd.isdecimal():
        raise RuntimeError(f"required file descriptor {name} is missing")
    with os.fdopen(int(raw_fd), "rb", closefd=True) as source:
        value = source.read(maximum + 1)
        trailing = source.read(1)
    if trailing or len(value) > maximum:
        raise RuntimeError(f"required file descriptor {name} is invalid")
    return value


def _read_inference_token() -> bytes:
    value = _read_required_fd(INFERENCE_TOKEN_FD_ENV, 4096)
    if not 16 <= len(value) <= 4096 or any(character in b" \t\r\n" for character in value):
        raise RuntimeError("inference credential is invalid")
    return value


def _consume_bootstrap_authorization() -> None:
    if _read_required_fd(BOOTSTRAP_AUTH_FD_ENV, 1) != b"1":
        raise RuntimeError("bootstrap authorization is invalid")


def _terminate(children: list[subprocess.Popen[bytes]]) -> None:
    for child in children:
        with suppress(ProcessLookupError):
            child.terminate()
    deadline = time.monotonic() + CHILD_STOP_SECONDS
    for child in children:
        if child.poll() is not None:
            continue
        remaining = max(0.0, deadline - time.monotonic())
        with suppress(subprocess.TimeoutExpired):
            child.wait(timeout=remaining)
    for child in children:
        if child.poll() is None:
            with suppress(ProcessLookupError):
                child.kill()
    for child in children:
        if child.poll() is None:
            child.wait(timeout=CHILD_STOP_SECONDS)


def main() -> None:
    if os.name != "posix" or os.geteuid() != 0:
        raise RuntimeError("RunPod image launcher requires Linux root supervision")
    _set_process_hardening()
    _consume_bootstrap_authorization()
    inference_token = _read_inference_token()
    _prepare_runtime_homes()
    children: list[subprocess.Popen[bytes]] = []

    shutting_down = False

    def request_shutdown(_: int, __: FrameType | None) -> None:
        nonlocal shutting_down
        shutting_down = True

    signal.signal(signal.SIGINT, request_shutdown)
    signal.signal(signal.SIGTERM, request_shutdown)

    try:
        proxy_read = _pipe_payload(inference_token)
        try:
            proxy = _spawn(
                proxy_command(),
                "proxy",
                pass_fds=(proxy_read,),
                extra_env={"SCHEMAWEAVE_PROXY_TOKEN_FD": str(proxy_read)},
            )
            children.append(proxy)
        finally:
            os.close(proxy_read)
        vllm = _spawn(vllm_command(), "vllm")
        children.append(vllm)
        while not shutting_down and all(child.poll() is None for child in children):
            time.sleep(0.5)
    finally:
        _terminate(children)


if __name__ == "__main__":
    main()
